# Welcome to Natural Sciences Computing Workshops

Use the menu on the left to navigate to each week's workshop.
